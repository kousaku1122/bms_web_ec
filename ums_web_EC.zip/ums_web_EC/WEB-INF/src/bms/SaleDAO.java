package bms;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Sale;

public class SaleDAO {

	private static final String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static final String URL = "jdbc:mysql://localhost/kandauniformdb";
	private static final String USER = "root";
	private static final String PASSWD = "root123";

	/**
	 *
	 * @return connection コネクションを取得する
	 */
	private static Connection getConnection() {
		Connection con = null; // コネクション
		try {
			Class.forName(RDB_DRIVE);
			// DBに接続
			con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	/*
	 * @return Book 指定されたISBN情報をもとにデータベースから書籍データを検索するインスタンスメソッド
	 */
	public ArrayList<Sale> selectBySales(String year, String month) {
		// コネクションとステートメントの宣言
		Connection con = null;
		Statement smt = null;

		// 検索した売却情報を格納するsaleオブジェクトを生成
		ArrayList<Sale> sale_list = new ArrayList<Sale>();
		try {
			// 検索用のSQL文
			String sql = "SELECT u.uniform_id, uniform_name, price, sum(quantity) as quantity FROM orderinfo o inner join uniforminfo u ON o.uniform_id=u.uniform_id "
					+ " WHERE ordered_at LIKE '" + year + "-" + month
					+ "%' GROUP BY u.uniform_id ORDER BY u.uniform_id";

			// データベースへ接続する
			con = SaleDAO.getConnection();
			// SQL文を送信するための準備
			smt = con.createStatement();

			// Statementオブジェクトの、executeQuery()メソッドを利用して、SQL文を発行し結果セットを取得
			ResultSet rs = smt.executeQuery(sql);

			// 結果セットからユーザデータを検索件数分すべて取り出し、ArrayListオブヘクトにUserオブジェクトとして格納
			while (rs.next()) {
				Sale sale = new Sale();
				sale.setUniformId(rs.getInt("uniform_id"));
				sale.setUniformName(rs.getString("uniform_name"));
				sale.setPrice(rs.getInt("price"));
				sale.setQuantity(rs.getInt("quantity"));
				sale_list.add(sale);
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();// Statementオブジェクトをクローズ
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();// Connectionオブジェクトをクローズ
				} catch (SQLException ignore) {
				}
			}
		}
		return sale_list;
	}

}
