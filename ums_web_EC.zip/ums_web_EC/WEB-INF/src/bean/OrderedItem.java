package bean;

/**
 * DTOクラス
 */
public class OrderedItem {
	private int orderId; // オーダー名
	private String userId; // ユーザ名
	private String uniformId; // ユニフォームID
	private String uniformName; // ユニフォーム名
	private int quantity;// 数量
	private int price;// 値段
	private String ordered_at;// 購入日付
	private int payment;
	private int sending;

	public OrderedItem() {
		// コンストラクタで値を初期化
		this.orderId = 0;
		this.userId = "";
		this.uniformId = "";
		this.quantity = 0;
		this.ordered_at = "";
		this.payment = 0;
		this.sending = 0;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	/**
	 * @return userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId セットする userId
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return uniformId
	 */
	public String getUniformId() {
		return uniformId;
	}

	/**
	 * @param uniformName セットする uniformName
	 */
	public void setUniformName(String uniformName) {
		this.uniformName = uniformName;
	}

	/**
	 * @return uniformName
	 */
	public String getUniformName() {
		return uniformName;
	}

	/**
	 * @param uniformId セットする uniformId
	 */
	public void setUniformId(String uniformId) {
		this.uniformId = uniformId;
	}

	/**
	 * @return price
	 */
	public int getPrice() {
		return price;
	}

	/**
	 * @param price セットする price
	 */
	public void setPrice(int price) {
		this.price = price;
	}

	/**
	 * @return quantity
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity セットする quantity
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return date
	 */
	public String getOrderedAt() {
		return ordered_at;
	}

	/**
	 * @param date セットする date
	 */
	public void setOrderedAt(String ordered_at) {
		this.ordered_at = ordered_at;
	}

	public int getPayment() {
		return payment;
	}

	public void setPayment(int payment) {
		this.payment = payment;
	}

	public int getSending() {
		return sending;
	}

	public void setSending(int sending) {
		this.sending = sending;
	}
}
