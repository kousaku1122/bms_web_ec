//プログラム名：NewAccountServlet
//プログラムの説明:ユーザー登録処理のサーブレット
//作成者:櫻井 康稀
//作成日:2022/07/22

package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.User;
import bms.UserDAO;
import util.SendMailTest;

public class NewAccountServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";
		try {
			// DAOオブジェクト宣言
			UserDAO userDao = new UserDAO();

			// DTOオブジェクト宣言
			User user = new User();

			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			// パラメータの取得
			String userId = request.getParameter("userId");
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			String address = request.getParameter("address");
			String password = request.getParameter("password");
			String passwordCheck = request.getParameter("passwordCheck");

			// 取得パラメータの設定
			user.setUserId(userId);
			user.setName(name);
			user.setEmail(email);
			user.setAddress(address);
			user.setPassword(password);
			user.setAuthority(1);

			// 重複チェック
			if (userDao.selectByUser(userId).getUserId() != null) {
				error = "入力したユーザーIDはすでに使用されています。";
				cmd = "newAccount";
				return;
			}

			// パスワード確認
			if (!password.equals(passwordCheck)) {
				error = "パスワードが一致しません。";
				cmd = "newAccount";
				return;
			}

			// 入力値の空白チェック
			if (userId.equals("") || password.equals("")) {
				error = "ユーザーIDまたはパスワードが入力されていません。";
				cmd = "newAccount";
				return;
			}

			// DB登録
			userDao.insert(user);

			// メールを送る
			SendMailTest sendMail = new SendMailTest();
			sendMail.setFromInfo("system.project.team01@kanda-it-school-system.com", "神田ユニフォーム");
			sendMail.setRecipients(user.getEmail());
			sendMail.setSubject("新規アカウントのご登録ありがとうございます。");
			sendMail.setText(user.getName() + "様\n\nアカウントのご登録ありがとうございます。\n以下内容で新規アカウント作成が完了しましたので、ご連絡致します。\n");

			sendMail.setText("ユーザID \t 名前 \t Email \t パスワード");

			// 書籍の合計金額
			int sum = 0;
			sendMail.setText(userId + "\t" + name + "\t" + email + "\t" + password + "\n\n");

			sendMail.setText("※以下URLにアクセス後、本メールに記載しているユーザIDとパスワードを入力することで引き続きお買い物をお楽しみ頂けます。\n\n");

			sendMail.setText("http://localhost:8080/ums_web_EC/view/login.jsp \n\n");

			sendMail.setText("何かご不明な点がございましたら、株式会社神田ユニフォームにお問い合わせください。");
			sendMail.forwardMail();

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、ユーザー登録処理は行えませんでした。";
			cmd = "newAccount";
		} finally {
			// エラーが無い場合
			if (error.equals("")) {
				// ListServletにフォワード
				request.getRequestDispatcher("/view/login.jsp").forward(request, response);
			}
			// エラーがある場合
			else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				// パスワードの不一致
				if (cmd.equals("newAccount")) {
					request.getRequestDispatcher("/view/newAccount.jsp").forward(request, response);
				} else {
					// error.jspにフォワード
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);

				}
			}
		}

	}
}