/*
 * プログラム名：ShowSalesByMonthServlet
 * プログラムの説明：売上げ一覧を月日で表示するためのサーブレット
 * 作成者：大橋嘉倫
 * 作成日付：2022/07/25
 */

package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Sale;
import bms.SaleDAO;

public class ShowSalesByMonthServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";
		try {
			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			// yearとmonthの入力パラメータを取得。
			String date = request.getParameter("date");
			String year = null;
			String month = null;

			year = date.substring(0, 4);
			month = date.substring(5, 7);
			if (year == null || month == null) {
				error = "月日を入力してください。";
				cmd = "showSalesByMonth";
				return;
			}

			// salesDAOクラスのインスタンス化⇒関連メソッドの呼び出し
			SaleDAO saleDao = new SaleDAO();
			ArrayList<Sale> saleList = saleDao.selectBySales(year, month);
			if (saleList.size() == 0) {
				error = "該当売り上げが見つかりません";
				cmd = "showSalesByMonth";
				return;
			}

			// 画面表示用日時
			String dispDate = year + "年" + month + "月";
			request.setAttribute("dispDate", dispDate);

			// 各データをリクエストスコープに格納
			request.setAttribute("sale_list", saleList);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示はできませんでした";
			cmd = "menu";

		} finally {
			if (error.equals("")) {
				request.getRequestDispatcher("/view/showSalesByMonth.jsp").forward(request, response);
			} else {
				if (cmd.equals("showSalesByMonth")) {
					request.setAttribute("error", error);
					request.getRequestDispatcher("/view/showSalesByMonth.jsp").forward(request, response);
				} else {
					request.setAttribute("error", error);
					request.setAttribute("cmd", cmd);
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
				}
			}
		}

	}
}
