package servlet;

/*
 * プログラム名：InsertIntoCartServlet
 * プログラムの説明：商品をカートに追加するプログラム
 * 作成者：樟木健太郎
 * 作成日：2022年7月25日
 */

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Order;
import bean.Uniform;
import bean.User;
import bms.UniformDAO;

public class InsertIntoCartServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 共通処理メソッドの呼び出し
		commonProcess(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 共通処理メソッドの呼び出し
		commonProcess(request, response);
	}

	private void commonProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String error = "";
		String cmd = "";

		try {
			// 入力データの文字コードの指定
			request.setCharacterEncoding("UTF-8");

			// セッションからUserオブジェクトを取得
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");

			// セッション切れの場合はエラー
			if (user == null) {
				error = "セッション切れの為、カートに追加できません。";
				cmd = "login";
				return;
			}

			// パラメータを取得
			int uniformId = Integer.parseInt(request.getParameter("uniformId"));
			int quantity = Integer.parseInt(request.getParameter("quantity"));

			// UniformDAOをインスタンス化
			UniformDAO ObjUniformDao = new UniformDAO();

			// Uniformのインスタンスを生成し、UniformDAOの関連メソッドを呼び出す
			Uniform uniform = ObjUniformDao.selectByUniformId(uniformId);

			// セッションからorder_listを取得
			ArrayList<Order> orderlist = (ArrayList<Order>) session.getAttribute("order_list");

			Order order = new Order();
			order.setUniformId(uniformId);
			order.setUserId(user.getUserId());

			// listがnullの場合は新しく定義
			if (orderlist == null) {
				orderlist = new ArrayList<Order>();

				order.setQuantity(quantity);
			}

			// Orderインスタンスを生成し、値を設定する
			int index = -1;
			for (int i = 0; i < orderlist.size(); i++) {
				if (orderlist.get(i).getUniformId() == uniformId) {
					order.setQuantity(orderlist.get(i).getQuantity() + quantity);

					// 該当インデックス
					index = i;
					orderlist.set(index, order);
				} else {
					order.setQuantity(quantity);
				}
			}

			// リストにorderを追加し、セッションに登録
			if (index == -1) {
				orderlist.add(order);
			}

			session.setAttribute("order_list", orderlist);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、カートに追加できません。";
			cmd = "topPage";
		} finally {
			// エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				request.getRequestDispatcher("/topPage").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
