/*
 * プログラム名：DeleteMyAccountServlet
 * プログラムの説明：会員情報を削除(退会)するサーブレット
 * 作成者：樟木健太郎
 * 作成日時：2022/7/21
 */

package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bms.UserDAO;

public class DeleteUserServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";

		try {
			// 入力データの文字コードの指定
			request.setCharacterEncoding("UTF-8");

			// useridのパラメータを取得
			String userId = request.getParameter("userId");

			// DAOオブジェクトをインスタンス化する
			UserDAO ObjUserDao = new UserDAO();

			// 書籍の削除をおこなうメソッドを呼び出す
			ObjUserDao.delete(userId);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、ユーザー削除処理は行えませんでした。";
			cmd = "menu";
		} finally {
			// エラーがない場合
			if (error.equals("")) {
				// ユーザー一覧画面にフォワード
				request.getRequestDispatcher("/listUser").forward(request, response);
			} else {
				// エラーがある場合、error.jspにフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}