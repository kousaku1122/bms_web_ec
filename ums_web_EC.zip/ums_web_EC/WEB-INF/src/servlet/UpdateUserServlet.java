//プログラム名：UpdateServlet
//プログラムの説明:ユーザー更新処理のサーブレット
//作成者:櫻井 康稀
//作成日:2022/07/22

package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.User;
import bms.UserDAO;

public class UpdateUserServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 共通処理メソッドの呼び出し
		commonProcess(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 共通処理メソッドの呼び出し
		commonProcess(request, response);
	}

	private void commonProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String error = "";
		String cmd = "";
		try {
			// DAOオブジェクト宣言
			UserDAO userDao = new UserDAO();

			// DTOオブジェクト宣言
			User user = new User();

			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			// パラメータの取得
			String userId = request.getParameter("userId");
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			String address = request.getParameter("address");
			String password = request.getParameter("password");
			String authority = request.getParameter("authority");

			// 取得パラメータの設定
			user.setUserId(userId);
			user.setName(name);
			user.setEmail(email);
			user.setAddress(address);
			user.setPassword(password);
			user.setAuthority(Integer.parseInt(authority));

			// DB登録
			userDao.update(user);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、ユーザー登録処理は行えませんでした。";
			cmd = "menu";
		} finally {
			// エラーが無い場合
			if (error.equals("")) {
				// ListlistUserにフォワード
				request.getRequestDispatcher("/listUser").forward(request, response);
			}
			// エラーがある場合
			else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				if (cmd.equals("updateUser")) {
					request.getRequestDispatcher("/view/updateUser.jsp").forward(request, response);
				} else {
					// error.jspにフォワード
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);

				}
			}
		}

	}
}
