package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.OrderedItem;
import bean.User;
import bms.OrderedItemDAO;
import bms.UserDAO;
import util.SendMailTest;

public class UpdateOrderedItemServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";
		try {
			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			// フォワードされた各パラメータを格納
			String userId = request.getParameter("userId");
			String str_orderId = request.getParameter("order_id");
			String str_payment = request.getParameter("payment");
			String str_sending = request.getParameter("sending");
			int order_id, payment, sending;

			if (userId.equals("")) {
				error = "ユーザーIDが未入力の為、入金状況更新処理は行えませんでした。";
				return;
			}
			if (str_orderId.equals("")) {
				error = "オーダー情報が未入力の為、入金状況更新処理は行えませんでした。";
				return;
			}

			if (str_payment.equals("")) {
				error = "入金情報が未入力の為、入金状況更新処理は行えませんでした。";
				return;
			}
			if (str_sending.equals("")) {
				error = "配送状況が未選択の為、配送状況更新処理は行えませんでした。";
				return;
			}

			try {
				// 価格値チェック（整数かどうか）
				order_id = Integer.parseInt(str_orderId);
			} catch (NumberFormatException e) {
				error = "オーダーIDの値が不正の為、入金状況変更処理は行えませんでした。";
				cmd = "list";
				return;
			}
			try {
				// 価格値チェック（整数かどうか）
				payment = Integer.parseInt(str_payment);
			} catch (NumberFormatException e) {
				error = "入金状況の値が不正の為、入金状況変更処理は行えませんでした。";
				cmd = "list";
				return;
			}
			try {
				// 在庫値チェック（整数かどうか）
				sending = Integer.parseInt(str_sending);
			} catch (NumberFormatException e) {
				error = "配送状況の値が不正の為、配送状況変更処理は行えませんでした。";
				cmd = "list";
				return;
			}

			// OrderedItemDTOオブジェクトの宣言
			OrderedItem objOrder = new OrderedItem();
			objOrder.setOrderId(order_id);
			objOrder.setPayment(payment);
			objOrder.setSending(sending);

			// UserDAOオブジェクトの宣言
			OrderedItemDAO objOrderDao = new OrderedItemDAO();

			// オーダー情報の取得
			ArrayList<OrderedItem> orderedList = objOrderDao.selectByUser(userId, order_id);
			// 該当情報を更新
			objOrderDao.update(objOrder);

			// ユーザIDからユーザnameを取得
			User user = new User();
			UserDAO userDao = new UserDAO();

			user = userDao.selectByUser(userId);

			// メール送信
			if (payment == 1 && sending == 0) {// 入金完了後
				// メール用合計金額
				int sum = 0;
				// 入金確認後にメールを送る
				SendMailTest sendMail = new SendMailTest();
				sendMail.setFromInfo("system.project.team01@kanda-it-school-system.com", "神田ユニフォーム");
				sendMail.setRecipients(user.getEmail());
				sendMail.setSubject("【入金完了通知】入金を確認致しました。");
				sendMail.setText(user.getName() + "様。\n\n注文番号" + order_id + "の入金を確認できましたので、ご連絡致します。\n\n");

				sendMail.setText("注文番号 \t 商品名 \t 個数 \t 価格");
				// 書籍の合計金額
				for (OrderedItem orderedItem : orderedList) {
					sendMail.setText(order_id + "\t" + orderedItem.getUniformName() + "\t" + orderedItem.getQuantity()
							+ "\t" + orderedItem.getPrice() + "\n\n");
					sum += (orderedItem.getQuantity() * orderedItem.getPrice());
				}
				sendMail.setText("合計 " + sum + "円\n\nまたのご利用よろしくお願いします。\n\n");

				sendMail.setText("何かご不明な点がございましたら、株式会社神田ユニフォームにお問い合わせください。");
				sendMail.forwardMail();
			} else if (payment == 1 && sending == 1) {// 配送完了後
				// メール用合計金額
				int sum = 0;
				// 入金確認後にメールを送る
				SendMailTest sendMail = new SendMailTest();
				sendMail.setFromInfo("system.project.team01@kanda-it-school-system.com", "神田ユニフォーム");
				sendMail.setRecipients(user.getEmail());
				sendMail.setSubject("【発送完了通知】発送を確認致しました。");
				sendMail.setText(user.getName() + "様。\n\n注文番号" + order_id + "の商品を登録住所に発送いたしましたので、ご連絡致します。\n\n");

				sendMail.setText("何かご不明な点がございましたら、株式会社神田ユニフォームにお問い合わせください。");
				sendMail.forwardMail();
			}

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示はできませんでした";
			cmd = "menu";
		} finally {
			if (error.equals("")) {
				// エラーがない場合
				request.getRequestDispatcher("/showOrderedItem").forward(request, response);
			} else {
				// エラーがある場合
				if (cmd.equals("menu")) {
					request.setAttribute("cmd", cmd);
				} else {
					error = "ユーザ入力値不正の為、登録できません";
					request.setAttribute("cmd", "user");
				}
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}