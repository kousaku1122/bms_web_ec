//プログラム名：ChangeAccountInfoServlet
//プログラムの説明:ユーザー更新処理のサーブレット
//作成者:櫻井 康稀
//作成日:2022/07/22

package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.User;
import bms.UserDAO;

public class ChangeAccountInfoServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";
		try {
			// DAOオブジェクト宣言
			UserDAO userDao = new UserDAO();

			cmd = "detailUser";
			// 取得したuserをセッションスコープへ登録
			HttpSession session = request.getSession();

			// DTOオブジェクト宣言
			User user = (User) session.getAttribute("user");

			// セッション切れの場合はログイン画面に戻る
			if (user == null) {
				error = "セッション切れの為、更新できません。";
				cmd = "login";
				return;
			}

			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			// パラメータの取得
			String userId = request.getParameter("userId");
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			String address = request.getParameter("address");
			String password = request.getParameter("password");

			// 入力値の空白チェック
			if (userId.equals("") || password.equals("")) {
				error = "ユーザーIDまたはパスワードが入力されていません。";
				cmd = "updateUser";
				return;
			}

			// 取得パラメータの設定
			user.setUserId(userId);
			user.setName(name);
			user.setEmail(email);
			user.setAddress(address);
			user.setPassword(password);
			user.setAuthority(1);

			// DB登録
			userDao.update(user);

			session.setAttribute("user", user);
		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、ユーザー登録処理は行えませんでした。";
			cmd = "login";
		} finally {
			// エラーが無い場合
			if (error.equals("")) {
				// detailUserにフォワード
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/accountInfo.jsp").forward(request, response);
			}
			// エラーがある場合
			else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				if (cmd.equals("updateUser")) {
					request.getRequestDispatcher("/view/updateUser.jsp").forward(request, response);
				} else {
					// error.jspにフォワード
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);

				}
			}
		}

	}
}