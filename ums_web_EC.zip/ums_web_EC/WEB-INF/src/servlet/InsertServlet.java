/*
 * プログラム名：InsertServlet
 * プログラム説明：商品登録のサーブレット
 * 作成日：2022/7/22
 * 作成者：大橋嘉倫
 */
package servlet;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import bean.Uniform;
import bms.UniformDAO;

@MultipartConfig
public class InsertServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";
		try {
			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			// DTOオブジェクトの宣言
			Uniform objuni = new Uniform();

			// DAOオブジェクトの宣言
			UniformDAO objDao = new UniformDAO();

			// フォワードされた各パラメータを格納
			String uniform_name = request.getParameter("uniform_name");
			String str_Price = request.getParameter("price");
			String str_Stock = request.getParameter("stock");
			String info = request.getParameter("info");
			// キャスト用変数の宣言
			int price, stock;

			// 全データの空白チェック
			if (uniform_name.equals("")) {
				error = "ユニフォーム名が未入力の為、登録処理は行えませんでした。";
				cmd = "list";
				return;
			}

			if (str_Price.equals("")) {
				error = "価格が未入力の為、登録処理は行えませんでした。";
				cmd = "list";
				return;
			}

			if (str_Stock.equals("")) {
				error = "在庫数が未入力の為、登録処理は行えませんでした。";
				cmd = "list";
				return;
			}

			if (info.equals("")) {
				error = "商品情報が未入力の為、登録処理は行えませんでした。";
				cmd = "list";
				return;
			}

			try {
				// 価格値チェック（整数かどうか）
				price = Integer.parseInt(str_Price);
			} catch (NumberFormatException e) {
				error = "価格の値が不正の為、登録処理は行えませんでした。";
				cmd = "list";
				return;
			}
			try {
				// 在庫値チェック（整数かどうか）
				stock = Integer.parseInt(str_Stock);
			} catch (NumberFormatException e) {
				error = "在庫の値が不正の為、登録処理は行えませんでした。";
				cmd = "list";
				return;
			}

			// パラメータの取得
			objuni.setUniformName(uniform_name);
			objuni.setPrice(price);
			objuni.setStock(stock);
			objuni.setInfo(info);

			// name属性がfileのファイルをPartオブジェクトとして取得
			Part part = request.getPart("file");

			// 画像パス
			String image = "";
			// ファイル名を取得
			// String filename=part.getSubmittedFileName();//ie対応が不要な場合
			String filename = part.getSubmittedFileName();

			// 画像更新する場合
			if (filename != "") {

				// アップロードするフォルダ
				ServletContext context = this.getServletContext();
				String path = getServletContext().getRealPath("/img/uniform_img");
				// 呼び出し用URL
				image = context.getContextPath() + "/img/uniform_img/" + filename;

				// 書き込み
				part.write(path + File.separator + filename);
				objuni.setImage(image);
			}

			// 更新メソッドの呼び出し
			objDao.insert(objuni);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示はできませんでした";
			cmd = "menu";

		} finally {
			if (error.equals("")) {
				request.getRequestDispatcher("/list").forward(request, response);
			} else {
				// エラーの場合の処理
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}
}
