/*
 * プログラム名：ShowHistoryConfirmServlet
 * プログラムの説明：購入履歴一覧を表示するためのサーブレット
 * 作成者：大橋嘉倫
 * 作成日付：2022/07/25
 */
package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.OrderedItem;
import bean.User;
import bms.OrderedItemDAO;

public class ShowHistoryConfirmServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";
		try {
			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			// セッションからUserオブジェクトを取得する
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");
			if (user == null) {
				// セッション切れのエラー処理
				error = "セッション切れのため、カート状況は確認出来ません。";
				cmd = "logout";
				return;
			}

			OrderedItemDAO orderedItemDAO = new OrderedItemDAO();
			ArrayList<OrderedItem> list = orderedItemDAO.selectByUser(user.getUserId());
			// Bookリストオブジェクトをリクエストスコープに格納
			request.setAttribute("ordered_list", list);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、購入状況確認は出来ません。";
			cmd = "menu";

		} finally {
			if (error.equals("")) {
				request.getRequestDispatcher("/view/showHistoryConfirm.jsp").forward(request, response);
			} else {
				// エラーの場合の処理
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}
}
