/*
 * プログラム名：HTML、JSP及びサーブレットを用いたWeb版書籍管理システム
 * プログラムの説明：
 * 作成者：大橋嘉倫
 * 作成日付：2022/06/24
 */
package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.User;
import bms.UserDAO;

public class ListUserServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 共通処理メソッドの呼び出し
		commonProcess(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 共通処理メソッドの呼び出し
		commonProcess(request, response);
	}

	private void commonProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String error = "";
		String cmd = "";
		try {
			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");
			// UserDAOオブジェクトの宣言
			UserDAO objDao = new UserDAO();

			// 配列宣言
			ArrayList<User> userList = objDao.selectAll();

			// 取得したuserリストをリクエストスコープへ登録
			request.setAttribute("user_list", userList);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示はできませんでした";
			cmd = "menu";
		} finally {
			if (error.equals("")) {
				request.getRequestDispatcher("/view/listUser.jsp").forward(request, response);
			} else {
				// エラーの場合の処理
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}
}