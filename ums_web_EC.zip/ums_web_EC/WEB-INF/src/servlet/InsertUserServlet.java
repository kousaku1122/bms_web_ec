//プログラム名：InsertUserServlet
//プログラムの説明:ユーザー登録処理のサーブレット
//作成者:櫻井 康稀
//作成日:2022/07/22

package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.User;
import bms.UserDAO;

public class InsertUserServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";
		try {
			// DAOオブジェクト宣言
			UserDAO userDao = new UserDAO();

			// DTOオブジェクト宣言
			User user = new User();

			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			// パラメータの取得
			String userId = request.getParameter("userId");
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			String address = request.getParameter("address");
			String password = request.getParameter("password");
			String passwordCheck = request.getParameter("passwordCheck");
			String authority = request.getParameter("authority");

			// パスワード確認
			if (!password.equals(passwordCheck)) {
				error = "パスワードが一致しません。";
				cmd = "insertUser";
				return;
			}

			// 入力値の空白チェック
			if (userId.equals("") || password.equals("")) {
				error = "ユーザーIDまたはパスワードが入力されていません。";
				cmd = "insertUser";
				return;
			}

			// 重複チェック
			if (userDao.selectByUser(userId).getUserId() != null) {
				error = "入力したユーザーIDはすでに使用されています。";
				cmd = "insertUser";
				return;
			}
			// 取得パラメータの設定
			user.setUserId(userId);
			user.setName(name);
			user.setEmail(email);
			user.setAddress(address);
			user.setPassword(password);
			user.setAuthority(Integer.parseInt(authority));

			// DB登録
			userDao.insert(user);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、ユーザー登録処理は行えませんでした。";
			cmd = "logout";
		} finally {
			// エラーが無い場合
			if (error.equals("")) {
				// ListServletにフォワード
				request.getRequestDispatcher("/view/menu.jsp").forward(request, response);
			}
			// エラーがある場合
			else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				// パスワードの不一致
				if (cmd.equals("insertUser")) {
					request.getRequestDispatcher("/view/insertUser.jsp").forward(request, response);
				} else {
					// error.jspにフォワード
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);

				}
			}
		}

	}
}