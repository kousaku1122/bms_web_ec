/*
 * プログラム名：トップページサーブレット
 * プログラムの説明：トップページに遷移する前に、ユニフォーム一覧を取得するサーブレット
 * 作成者：大橋嘉倫
 * 作成日時：2022/7/21
 */
package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Uniform;
import bean.User;
import bms.UniformDAO;

public class TopPageServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 共通処理メソッドの呼び出し
		commonProcess(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 共通処理メソッドの呼び出し
		commonProcess(request, response);
	}

	private void commonProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String error = "";
		String cmd = "";
		try {
			// セッションからUserオブジェクトを取得
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");

			// セッション切れの場合はエラー
			if (user == null) {
				error = "セッション切れの為、表示できません。";
				cmd = "login";
			}

			// 配列宣言
			ArrayList<Uniform> uniform_list = new ArrayList<Uniform>();

			// UniformDAOオブジェクトの宣言
			UniformDAO objDao = new UniformDAO();
			uniform_list = objDao.selectAll();

			// 取得したBookリストをリクエストスコープへ登録
			request.setAttribute("uniform_list", uniform_list);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、ログイン出来ません。";
			cmd = "login";
		} finally {
			// エラーがない場合
			if (error.equals("")) {
				request.getRequestDispatcher("/view/topPage.jsp").forward(request, response);

			} else {
				// エラーがある場合、error.jspにフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
