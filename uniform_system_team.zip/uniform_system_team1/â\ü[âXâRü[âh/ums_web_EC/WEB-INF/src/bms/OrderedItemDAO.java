package bms;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.OrderedItem;

public class OrderedItemDAO {

	private static final String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static final String URL = "jdbc:mysql://localhost/kandauniformdb";
	private static final String USER = "root";
	private static final String PASSWD = "root123";

	/**
	 *
	 * @return connection コネクションを取得する
	 */
	private static Connection getConnection() {
		Connection con = null; // コネクション
		try {
			Class.forName(RDB_DRIVE);
			// DBに接続
			con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	/*
	 * @return list データベースからOrderedItemデータの検索を行うメソッド
	 * テーブルに登録された全てのOrderedItemデータをArrayListへ格納し、戻り値として返す
	 */
	public ArrayList<OrderedItem> selectAll() {

		// コネクションとステートメントの宣言
		Connection con = null;
		Statement smt = null;

		// 配列宣言
		ArrayList<OrderedItem> list = new ArrayList<OrderedItem>();

		// SQL文作成
		// String sql = "SELECT o.order_id,o.user_id,u.uniform_id,o.ordered_at FROM
		// uniforminfo u INNER JOIN orderinfo o ON u.uniform_id=o.uniform_id";
		String sql = "SELECT * FROM orderinfo ORDER BY order_id";

		try {
			// DBに接続
			con = OrderedItemDAO.getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果をArrayListに格納
			while (rs.next()) {
				OrderedItem objDto = new OrderedItem();
				objDto.setOrderId(rs.getInt("order_id"));
				objDto.setUserId(rs.getString("user_id"));
				objDto.setUniformId(rs.getString("uniform_id"));
				objDto.setQuantity(rs.getInt("quantity"));
				objDto.setOrderedAt(rs.getString("ordered_at"));
				objDto.setPayment(rs.getInt("payment"));
				objDto.setSending(rs.getInt("sending"));
				list.add(objDto);
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return list;
	}

	/*
	 * @return DBのuseridから指定ユーザの条件に合致する情報を取得するメソッド①
	 */
	public ArrayList<OrderedItem> selectByUser(String userid) {
		// コネクションとステートメントの宣言
		Connection con = null;
		Statement smt = null;

		// 検索したユーザ情報を格納するOrderedItemリストオブジェクトを生成
		ArrayList<OrderedItem> ordered_list = new ArrayList<OrderedItem>();
		try {
			// 検索用のSQL文
			String sql = "SELECT o.user_id , u.uniform_name, u.price, u.uniform_id , o.quantity, o.ordered_at, o.payment, o.sending FROM uniforminfo u, orderinfo o WHERE u.uniform_id = o.uniform_id and o.user_id = '"
					+ userid + "'";

			// データベースへ接続する
			con = OrderedItemDAO.getConnection();
			// SQL文を送信するための準備
			smt = con.createStatement();

			// Statementオブジェクトの、executeQuery()メソッドを利用して、SQL文を発行し結果セットを取得
			ResultSet rs = smt.executeQuery(sql);

			// 結果セットからオーダーデータを検索件数分すべて取り出し、ArrayListオブヘクトにOrderedItemオブジェクトとして格納
			while (rs.next()) {
				OrderedItem ord_item = new OrderedItem();
				ord_item.setUserId(rs.getString("user_id"));
				ord_item.setUniformId(rs.getString("uniform_id"));
				ord_item.setUniformName(rs.getString("uniform_name"));
				ord_item.setPrice(rs.getInt("price"));
				ord_item.setQuantity(rs.getInt("quantity"));
				ord_item.setOrderedAt(rs.getString("ordered_at"));
				ord_item.setPayment(rs.getInt("payment"));
				ord_item.setSending(rs.getInt("sending"));
				ordered_list.add(ord_item);
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();// Statementオブジェクトをクローズ
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();// Connectionオブジェクトをクローズ
				} catch (SQLException ignore) {
				}
			}
		}
		return ordered_list;
	}

	/*
	 * @return DBのuseridとorderidから指定ユーザの条件に合致する情報を取得するメソッド②
	 */
	public ArrayList<OrderedItem> selectByUser(String userid, int orderid) {
		// コネクションとステートメントの宣言
		Connection con = null;
		Statement smt = null;

		// 検索したユーザ情報を格納するOrderedItemリストオブジェクトを生成
		ArrayList<OrderedItem> ordered_list = new ArrayList<OrderedItem>();
		try {
			// 検索用のSQL文
			String sql = "SELECT o.user_id , u.uniform_name, u.price, u.uniform_id , o.quantity, o.ordered_at FROM uniforminfo u, orderinfo o WHERE u.uniform_id = o.uniform_id and o.user_id = '"
					+ userid + "' and o.order_id = " + orderid;

			// データベースへ接続する
			con = OrderedItemDAO.getConnection();
			// SQL文を送信するための準備
			smt = con.createStatement();

			// Statementオブジェクトの、executeQuery()メソッドを利用して、SQL文を発行し結果セットを取得
			ResultSet rs = smt.executeQuery(sql);

			// 結果セットからオーダーデータを検索件数分すべて取り出し、ArrayListオブヘクトにOrderedItemオブジェクトとして格納
			while (rs.next()) {
				OrderedItem ord_item = new OrderedItem();
				ord_item.setUserId(rs.getString("user_id"));
				ord_item.setUniformId(rs.getString("uniform_id"));
				ord_item.setUniformName(rs.getString("uniform_name"));
				ord_item.setPrice(rs.getInt("price"));
				ord_item.setQuantity(rs.getInt("quantity"));
				ord_item.setOrderedAt(rs.getString("ordered_at"));
				ordered_list.add(ord_item);
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();// Statementオブジェクトをクローズ
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();// Connectionオブジェクトをクローズ
				} catch (SQLException ignore) {
				}
			}
		}
		return ordered_list;
	}

	/*
	 * @return データベースの書籍データを更新するインスタンスメソッド
	 */
	public void update(OrderedItem _orderedItem) {
		Connection con = null;
		Statement smt = null;

		// 更新用のSQL文
		String sql = "UPDATE orderinfo SET" + " payment ='" + _orderedItem.getPayment() + "'," + " sending ="
				+ _orderedItem.getSending() + " WHERE order_id ='" + _orderedItem.getOrderId() + "'";

		try {
			// データベースへ接続する
			con = getConnection();
			// SQL文を送信するための準備
			smt = con.createStatement();

			// 引数に受け取った更新系のSQL文を実行
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();// Statementオブジェクトをクローズ
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();// Connectionオブジェクトをクローズ
				} catch (SQLException ignore) {
				}
			}
		}
	}
}
