package bms;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Uniform;

public class UniformDAO {

	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/kandauniformdb";
	private static String USER = "root";
	private static String PASS = "root123";

	// DB接続情報を利用してDBに接続するメソッド
	private static Connection getConnection() {

		Connection con = null;
		try {
			Class.forName(RDB_DRIVE);
			con = DriverManager.getConnection(URL, USER, PASS);
			return con;

		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	// DBの全データをArrayListに格納するメソッド
	public ArrayList<Uniform> selectAll() {

		Connection con = null;
		Statement smt = null;

		ArrayList<Uniform> uniformList = new ArrayList<Uniform>();

		String sql = "SELECT * FROM uniforminfo ORDER BY uniform_id";

		try {
			con = getConnection();
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				Uniform uniform = new Uniform();
				uniform.setUniformId(rs.getInt("uniform_id"));
				uniform.setUniformName(rs.getString("uniform_name"));
				uniform.setPrice(rs.getInt("price"));
				uniform.setStock(rs.getInt("stock"));
				uniform.setImage(rs.getString("image"));
				uniform.setInfo(rs.getString("info"));
				uniform.setCreatedAt(rs.getString("created_at"));
				uniformList.add(uniform);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}

		return uniformList;

	}

	/*
	 * @return void データベースにuserデータを登録するインスタンスメソッド
	 */
	public void insert(Uniform uniform) {

		// コネクションとステートメントの宣言
		Connection con = null;
		Statement smt = null;
		try {
			// 登録用のSQL文を文字列として定義
			String sql = "INSERT INTO uniforminfo VALUES (" + uniform.getUniformId() + ",'" + uniform.getUniformName()
					+ "'," + uniform.getPrice() + "," + uniform.getStock() + ",'" + uniform.getImage() + "','"
					+ uniform.getInfo() + "'," + uniform.getCreatedAt() + ")";

			// getConnectionとcreateStatementのオブジェクトを生成
			con = UniformDAO.getConnection();
			smt = con.createStatement();
			// SQL文を発行しuserデータを登録
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();// Statementオブジェクトをクローズ
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();// Connectionオブジェクトをクローズ
				} catch (SQLException ignore) {
				}
			}
		}
	}

	// uniformIdと一致する商品情報を検索するメソッド
	public Uniform selectByUniformId(int uniform_id) {

		Connection con = null;
		Statement smt = null;

		Uniform uniform = new Uniform();

		String sql = "SELECT * FROM uniforminfo WHERE uniform_id = " + uniform_id;

		try {
			con = getConnection();
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				uniform.setUniformId(rs.getInt("uniform_id"));
				uniform.setUniformName(rs.getString("uniform_name"));
				uniform.setPrice(rs.getInt("price"));
				uniform.setStock(rs.getInt("stock"));
				uniform.setImage(rs.getString("image"));
				uniform.setInfo(rs.getString("info"));
				uniform.setCreatedAt(rs.getString("created_at"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}

		return uniform;
	}

	// 指定されたユニフォームのデータを削除するメソッド
	public void delete(int uniform_id) {

		Connection con = null;
		Statement smt = null;

		try {

			con = getConnection();
			smt = con.createStatement();

			String sql = "DELETE FROM uniforminfo WHERE uniform_id = " + uniform_id;

			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	// 商品情報を更新するメソッド
	// @param 登録する商品情報
	// @return なし
	public void update(Uniform uniform) {

		Connection con = null;
		Statement smt = null;

		try {

			con = getConnection();
			smt = con.createStatement();

			String sql = "UPDATE uniforminfo SET uniform_id = " + uniform.getUniformId() + ",uniform_name = '"
					+ uniform.getUniformName() + "',price = " + uniform.getPrice() + ",stock = " + uniform.getStock()
					+ ",info = '" + uniform.getInfo() + "',image = '" + uniform.getImage() + "' WHERE uniform_id = "
					+ uniform.getUniformId();

			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

}
