package bean;

public class Order {

	private int orderId;
	private String userId;
	private int uniformId;
	private int quantity;
	private String orderedAt;

	public Order() {
		this.orderId = 0;
		this.userId = null;
		this.uniformId = 0;
		this.quantity = 0;
		this.orderedAt = "CURRENT_TIMESTAMP";
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getUniformId() {
		return uniformId;
	}

	public void setUniformId(int uniformId) {
		this.uniformId = uniformId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getOrderedAt() {
		return orderedAt;
	}

	public void setOrderedAt(String orderedAt) {
		this.orderedAt = orderedAt;
	}

}
