package bean;

/**
 * DTOクラス
 */
public class Sale {
	private int uniformId; // ISBN
	private String uniformName; // タイトル
	private int price; // 値段
	private int quantity;

	public Sale() {
		// コンストラクタで値を初期化
		this.uniformId = 0;
		this.uniformName = "";
		this.price = 0;
		this.quantity = 0;
	}

	public Sale(Uniform _uniform, int quantity) {
		// コンストラクタで値を初期化
		this.uniformId = _uniform.getUniformId();
		this.uniformName = _uniform.getUniformName();
		this.price = _uniform.getPrice();
		this.quantity = quantity;
	}

	/**
	 * @return uniformId
	 */
	public int getUniformId() {
		return uniformId;
	}

	/**
	 * @param uniformId セットする uniformId
	 */
	public void setUniformId(int _uniformId) {
		this.uniformId = _uniformId;
	}

	/**
	 * @return uniformName
	 */
	public String getUniformName() {
		return uniformName;
	}

	/**
	 * @param uniformName セットする uniformName
	 */
	public void setUniformName(String _uniformName) {
		this.uniformName = _uniformName;
	}

	/**
	 * @return price
	 */
	public int getPrice() {
		return price;
	}

	/**
	 * @param price セットする price
	 */
	public void setPrice(int _price) {
		this.price = _price;
	}

	/**
	 * @return price
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity セットする quantity
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
