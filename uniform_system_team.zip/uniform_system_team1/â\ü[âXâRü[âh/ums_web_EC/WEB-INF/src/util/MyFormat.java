package util;

import java.text.DecimalFormat;

public class MyFormat {
	/*
	 * 引数に受け取った金額データを「￥付き、３桁カンマ区切り、小数点第2位（.00）」の形式に変換するインスタンスメソッド
	 */
	public String moneyFormat(int price) {
		DecimalFormat df = new DecimalFormat("\u00A5###,##0");
		return df.format(price);
	}
}
