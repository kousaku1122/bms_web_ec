/*
 * プログラム名：ListServlet
 * プログラムの説明：ユニフォーム一覧を表示するためのサーブレット
 * 作成者：大橋嘉倫
 * 作成日付：2022/07/21
 */
package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Uniform;
import bms.UniformDAO;

public class ListServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 共通処理メソッドの呼び出し
		commonProcess(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 共通処理メソッドの呼び出し
		commonProcess(request, response);
	}

	private void commonProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		{
			String error = "";
			String cmd = "";
			try {
				// 配列宣言
				ArrayList<Uniform> uniform_list = new ArrayList<Uniform>();

				// BookDAOオブジェクトの宣言
				UniformDAO objDao = new UniformDAO();
				uniform_list = objDao.selectAll();

				// 取得したBookリストをリクエストスコープへ登録
				request.setAttribute("uniform_list", uniform_list);

			} catch (IllegalStateException e) {
				error = "DB接続エラーの為、一覧表示はできませんでした";
				cmd = "menu";
			} finally {
				if (error.equals("")) {
					request.getRequestDispatcher("/view/list.jsp").forward(request, response);
				} else {
					// エラーの場合の処理
					request.setAttribute("error", error);
					request.setAttribute("cmd", cmd);
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
				}
			}
		}
	}
}