/*
 * プログラム名：GuestLoginServlet
 * プログラムの説明：ゲストログイン情報を照合するサーブレット
 * 作成者：大橋嘉倫
 * 作成日時：2022/7/20
 */
package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.User;
import bms.UserDAO;

public class GuestLoginServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";
		try {
			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			// UserDAOオブジェクトの宣言
			UserDAO objDao = new UserDAO();

			// user情報を取得
			User user = new User();

			// userIdの定義＆初期化
			String str_userid = null;

			// ゲストIDがユニークになるまで繰り返し
			while (true) {
				// ゲストIDの取得
				str_userid = (Integer.valueOf((int) (Math.random() * 10000))).toString();

				// ユーザIDの重複チェック
				if (objDao.selectByUser(str_userid).getUserId() != null) {
					// 既存データと被っている場合、繰り返し
					continue;
				}
				// ユニークになった場合、繰り返しを抜ける
				break;
			}

			// ゲスト権限
			int authority = 3;

			// ゲストユーザIDと権限のみセット
			user.setUserId(str_userid);
			user.setAuthority(authority);

			// ゲストユーザ登録
			objDao.insert(user);

			// 取得したuserをセッションスコープへ登録
			HttpSession session = request.getSession();
			session.setAttribute("user", user);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、ログイン出来ません。";
			cmd = "login";
		} finally {
			// エラーがない場合
			if (error.equals("")) {
				request.getRequestDispatcher("/topPage").forward(request, response);
			}
			// ログインエラーの場合
			else if (cmd.equals("login")) {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/login.jsp").forward(request, response);
			} else {
				// エラーがある場合、error.jspにフォワード
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
