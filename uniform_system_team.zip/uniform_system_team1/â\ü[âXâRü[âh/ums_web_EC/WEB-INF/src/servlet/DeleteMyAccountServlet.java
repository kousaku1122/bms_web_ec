/*
 * プログラム名：DeleteMyAccountServlet
 * プログラムの説明：会員情報を削除(退会)するサーブレット
 * 作成者：樟木健太郎
 * 作成日時：2022/7/21
 */
package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.User;
import bms.UserDAO;

public class DeleteMyAccountServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";

		try {
			// 入力データの文字コードの指定
			request.setCharacterEncoding("UTF-8");

			// useridを取得
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");

			// セッション切れの場合はログイン画面に戻る
			if (user == null) {
				error = "セッション切れの為、退会はできません。";
				cmd = "login";
				return;
			}

			String userId = String.valueOf(user.getUserId());

			// DAOクラスをインスタンス化する
			UserDAO ObjUserDao = new UserDAO();

			// userIdを引数にして、ユーザーの削除をおこなうメソッドを呼び出す
			ObjUserDao.delete(userId);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、退会処理は行えませんでした。";
			cmd = "login";
		} finally {
			// エラーがない場合
			if (error.equals("")) {
				// 退会後、login.jspにフォワード
				request.getRequestDispatcher("/view/login.jsp").forward(request, response);
			} else {
				// エラーがある場合、error.jspにフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}