/*
 * プログラム名：DetailUserServlet
 * プログラムの説明：ユーザー詳細を表示するプログラム
 * 作成者：樟木健太郎
 * 作成日：2022年7月22日
 */
package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.User;
import bms.UserDAO;

public class DetailUserServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 共通処理メソッドの呼び出し
		commonProcess(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 共通処理メソッドの呼び出し
		commonProcess(request, response);
	}

	private void commonProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String error = "";
		String cmd = "";

		try {

			// 入力データの文字コードの指定
			request.setCharacterEncoding("UTF-8");

			// useridとcmd(フォワード先を区別するパラメータ)を取得
			String userId = request.getParameter("userId");
			cmd = request.getParameter("cmd");

			// UserDAOをインスタンス化
			UserDAO userDaoObj = new UserDAO();

			// ユーザー情報を検索し、戻り値としてUserオブジェクトを取得
			User user = userDaoObj.selectByUser(userId);

			// 詳細情報のエラーチェック
			if (user.getUserId() == null) {
				if (cmd.equals("detailUser")) {
					error = "表示対象のユーザーが存在しない為、詳細情報は表示できませんでした。";
				} else if (cmd.equals("updateUser")) {
					error = "更新対象のユーザーが存在しない為、変更画面は表示できませんでした。";
				}
				cmd = "listUser";
				return;
			}

			// 取得したuserをリクエストスコープに格納
			request.setAttribute("user", user);

		} catch (IllegalStateException e) {
			if (cmd.equals("detailUser")) {
				error = "DB接続エラーの為、ユーザー詳細は表示できませんでした。";
			} else if (cmd.equals("updateUser")) {
				error = "DB接続エラーの為、変更画面は表示できませんでした。";
			}
			cmd = "menu";
		} finally {
			// エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				if (cmd.equals("detailUser")) {
					request.getRequestDispatcher("/view/detailUser.jsp").forward(request, response);
				} else if (cmd.equals("updateUser")) {
					request.getRequestDispatcher("/view/updateUser.jsp").forward(request, response);
				}
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);

			}
		}

	}
}
