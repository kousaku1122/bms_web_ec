/*
 * プログラム名：BuyConfirmServlet
 * プログラムの説明：商品購入を確定するプログラム
 * 作成者：樟木健太郎
 * 作成日：2022年7月25日
 */
package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Order;
import bean.Uniform;
import bean.User;
import bms.OrderDAO;
import bms.UniformDAO;
import util.SendMailTest;

public class BuyConfirmServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";

		try {

			// セッションからUserオブジェクトを取得
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");

			// セッション切れの場合はエラー
			if (user == null) {
				error = "セッション切れの為、購入はできません。";
				cmd = "login";
			}

			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			// パラメータの取得
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			String address = request.getParameter("address");

			if (user.getAuthority() == 3) {
				user.setName(name);
				user.setEmail(email);
				user.setAddress(address);
			}
			// セッションからorder_listを取得
			ArrayList<Order> orderList = (ArrayList<Order>) session.getAttribute("order_list");

			// カートの中身が空の場合はエラー
			if (orderList == null) {
				error = "カートの中に何もなかったので、購入はできません。";
				cmd = "topPage";
			}

			// 各DAOをインスタンス化
			UniformDAO ObjUniformDao = new UniformDAO();
			OrderDAO ObjOrderDao = new OrderDAO();

			// Uniform型のArrayListを定義
			ArrayList<Uniform> uniformList = new ArrayList<Uniform>();

			// orderListの各要素のユニフォームIDに該当するユニフォームデータをlistに追加
			for (Order order : orderList) {
				Uniform uniform = ObjUniformDao.selectByUniformId(order.getUniformId());
				ObjOrderDao.insert(order);

				// 在庫数計算
				uniform.setStock(uniform.getStock() - order.getQuantity());
				ObjUniformDao.update(uniform);

				uniformList.add(uniform);
			}

			// 各Listをリクエストスコープに格納
			request.setAttribute("uniform_list", uniformList);
			request.setAttribute("order_list", orderList);

			// メールを送る
			SendMailTest sendMail = new SendMailTest();
			sendMail.setFromInfo("system.project.team01@kanda-it-school-system.com", "神田ユニフォーム");
			sendMail.setRecipients(user.getEmail());
			sendMail.setSubject("ユニフォームのご購入ありがとうございます。");
			sendMail.setText(user.getName() + "様\n\nユニフォームのご購入ありがとうございます。\n以下内容でご注文を受け付けましたので、ご連絡致します。\n");

			sendMail.setText("商品ID \t 商品名 \t 価格 \t 購入数 \t 小計");
			// 書籍の合計金額
			int sum = 0;
			for (int i = 0; i < orderList.size(); i++) {
				sendMail.setText(uniformList.get(i).getUniformName() + "\t" + uniformList.get(i).getPrice() + "\t"
						+ orderList.get(i).getQuantity() + "\t"
						+ (uniformList.get(i).getPrice() * orderList.get(i).getQuantity()));

				sum += (uniformList.get(i).getPrice() * orderList.get(i).getQuantity());
			}

			sendMail.setText("\n\n合計 " + sum + "円\n\nまたのご利用よろしくお願いします。");
			sendMail.forwardMail();

			// セッションのorder_listをnullにする
			session.setAttribute("order_list", null);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、購入はできません。";
			cmd = "topPage";
		} finally {
			// エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				request.getRequestDispatcher("/view/buyConfirm.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}
}
