package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.OrderedItem;
import bms.OrderedItemDAO;

public class ShowOrderedItemServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";
		try {
			OrderedItemDAO orderedItemDAO = new OrderedItemDAO();
			ArrayList<OrderedItem> list = orderedItemDAO.selectAll();
			// OrderedItemリストオブジェクトをリクエストスコープに格納
			request.setAttribute("ordered_list", list);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、購入状況確認は出来ません。";
			cmd = "menu";

		} finally {
			if (error.equals("")) {
				request.getRequestDispatcher("/view/showOrderedItem.jsp").forward(request, response);
			} else {
				// エラーの場合の処理
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}
}
