package servlet;

/*
 * プログラム名：DetailUniformServlet
 * プログラムの説明：ユニフォーム詳細を表示するプログラム
 * 作成者：樟木健太郎
 * 作成日：2022年7月22日
 */

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Uniform;
import bms.UniformDAO;

public class DetailServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";
		int authority = 0;

		try {

			// 入力データの文字コードの指定
			request.setCharacterEncoding("UTF-8");

			// uniformidとcmd(フォワード先を区別するパラメータ)を取得
			int uniformId = Integer.parseInt(request.getParameter("uniformId"));
			cmd = request.getParameter("cmd");

			authority = Integer.parseInt(request.getParameter("authority"));
			// DAOクラスをインスタンス化する
			UniformDAO ObjUniformDao = new UniformDAO();

			// ユーザー情報を検索し、戻り値としてUserオブジェクトを取得
			Uniform uniform = ObjUniformDao.selectByUniformId(uniformId);

			// 詳細情報のエラーチェック
			if (uniform.getUniformId() == 0) {
				if (cmd.equals("detail")) {
					error = "表示対象のユニフォームが存在しない為、詳細情報は表示できませんでした。";
				} else if (cmd.equals("update")) {
					error = "更新対象のユニフォームが存在しない為、変更画面は表示できませんでした。";
				}
				cmd = "topPage";
				return;
			}

			// 取得した商品をリクエストスコープに格納
			request.setAttribute("uniform", uniform);
			request.setAttribute("authority", authority);

		} catch (IllegalStateException e) {
			if (cmd.equals("detail")) {
				error = "DB接続エラーの為、ユニフォーム詳細は表示できませんでした。";
				cmd = "login";
			} else if (cmd.equals("update")) {
				error = "DB接続エラーの為、変更画面は表示できませんでした。";
				cmd = "login";
			}
			cmd = "menu";
		} finally {
			// エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				if (cmd.equals("detail")) {
					request.getRequestDispatcher("/view/detail.jsp").forward(request, response);
				} else if (cmd.equals("updateUniform")) {
					request.getRequestDispatcher("/view/update.jsp").forward(request, response);
				} else if (cmd.equals("topPage")) {
					request.getRequestDispatcher("/topPage").forward(request, response);
				}
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);

			}
		}

	}
}