//プログラム名：UpdateServlet
//プログラムの説明:ユーザー更新処理のサーブレット
//作成者:櫻井 康稀
//作成日:2022/07/22

package servlet;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import bean.Uniform;
import bms.UniformDAO;

@MultipartConfig
public class UpdateServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 共通処理メソッドの呼び出し
		commonProcess(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 共通処理メソッドの呼び出し
		commonProcess(request, response);
	}

	private void commonProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String error = "";
		String cmd = "";
		try {
			// DAOオブジェクト宣言
			UniformDAO uniformDao = new UniformDAO();

			// DTOオブジェクト宣言
			Uniform uniform = new Uniform();

			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			// パラメータの取得
			String uniformId = request.getParameter("uniformId");
			String uniformName = request.getParameter("uniformName");
			String price = request.getParameter("price");
			String stock = request.getParameter("stock");
			String info = request.getParameter("info");
			String oldImg = request.getParameter("oldImg");

			// 取得パラメータの設定
			uniform.setUniformId(Integer.parseInt(uniformId));
			uniform.setUniformName(uniformName);
			uniform.setPrice(Integer.parseInt(price));
			uniform.setStock(Integer.parseInt(stock));
			uniform.setInfo(info);

			// name属性がfileのファイルをPartオブジェクトとして取得
			Part part = request.getPart("file");

			// 画像パス
			String image = "";
			// ファイル名を取得
			// String filename=part.getSubmittedFileName();//ie対応が不要な場合
			String filename = part.getSubmittedFileName();

			// 画像更新する場合
			if (filename != "") {

				// アップロードするフォルダ
				ServletContext context = this.getServletContext();
				String path = getServletContext().getRealPath("/img/uniform_img");
				// 呼び出し用URL
				image = context.getContextPath() + "/img/uniform_img/" + filename;

				// 書き込み
				part.write(path + File.separator + filename);
			} else {
				image = oldImg;
			}
			uniform.setImage(image);

			// DB登録
			uniformDao.update(uniform);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、ユーザー登録処理は行えませんでした。";
			cmd = "menu";
		} finally {
			// エラーが無い場合
			if (error.equals("")) {
				// ListlistUserにフォワード
				request.getRequestDispatcher("/list").forward(request, response);
			}
			// エラーがある場合
			else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				if (cmd.equals("update")) {
					request.getRequestDispatcher("/view/update.jsp").forward(request, response);
				} else {
					// error.jspにフォワード
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);

				}
			}
		}

	}
}
