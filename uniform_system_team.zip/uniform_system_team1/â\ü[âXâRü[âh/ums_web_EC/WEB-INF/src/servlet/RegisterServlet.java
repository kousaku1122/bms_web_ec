package servlet;

/*
 * プログラム名：RegisterServlet
 * プログラムの説明：商品の購入処理をするプログラム
 * 作成者：樟木健太郎
 * 作成日：2022年7月25日
 */

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Order;
import bean.Uniform;
import bean.User;
import bms.UniformDAO;

public class RegisterServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";

		try {

			// セッションからUserオブジェクトを取得
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");

			// セッション切れの場合はエラー
			if (user == null) {
				error = "セッション切れの為、購入できません。";
				cmd = "login";
				return;
			}

			// セッションからorder_listを取得
			ArrayList<Order> orderList = (ArrayList<Order>) session.getAttribute("order_list");

			if (orderList == null || orderList.size() == 0) {
				error = "カートに商品がないため、購入できません。";
				cmd = "topPage";
				return;
			}

			// UniformDAOをインスタンス化
			UniformDAO ObjUniformDao = new UniformDAO();

			// Uniform型のArrayListを定義
			ArrayList<Uniform> uniformList = new ArrayList<Uniform>();

			// orderListの各要素のuniformIdに該当するデータをuniformに格納
			for (Order order : orderList) {
				Uniform uniform = ObjUniformDao.selectByUniformId(order.getUniformId());
				uniformList.add(uniform);
			}

			// 各Listをリクエストスコープに格納
			request.setAttribute("uniform_list", uniformList);
			// request.setAttribute("order_list", orderList);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、カート状況は確認できません。";
			cmd = "topPage";
		} finally {
			// エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				request.getRequestDispatcher("/view/register.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}
}
