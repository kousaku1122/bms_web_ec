package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.User;
import bms.UserDAO;

public class LogoutServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// セッションの削除
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");

		UserDAO userDao = new UserDAO();

		// ゲストユーザーの削除
		if (user != null) {
			if (user.getAuthority() == 3) {
				userDao.delete(user.getUserId());
			}
		}

		session.invalidate();

		// ログアウトメッセージ
		String message = "ログアウトしました";
		request.setAttribute("message", message);

		// login.jspにフォワード
		request.getRequestDispatcher("/view/login.jsp").forward(request, response);
	}
}
