/*
 * プログラム名：LoginServlet
 * プログラムの説明：ログイン情報を照合するサーブレット
 * 作成者：大橋嘉倫
 * 作成日時：2022/7/20
 */
package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.User;
import bms.UserDAO;

public class LoginServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";
		// 権限
		int authority = 0;
		try {
			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			// ログイン情報の取得
			String userid = request.getParameter("userId");
			String password = request.getParameter("password");

			// 空データの確認
			if (userid.equals("") || password.equals("")) {
				cmd = "login";
				error = "入力データがありません。";
				return;
			}

			// UserDAOオブジェクトの宣言
			UserDAO objDao = new UserDAO();

			// user情報を取得
			User user = new User();
			user = objDao.selectByUser(userid, password);

			// 権限の取得
			authority = user.getAuthority();

			// userデータが存在する場合
			if (user.getUserId() != null) {
				// 取得したuserをセッションスコープへ登録
				HttpSession session = request.getSession();
				session.setAttribute("user", user);

				// useridとpasswordをクッキーへ登録
				Cookie userCookie = new Cookie("user", userid);
				userCookie.setMaxAge(60 * 60 * 24 * 5);
				response.addCookie(userCookie);

				Cookie passwordCookie = new Cookie("pass", password);
				passwordCookie.setMaxAge(60 * 60 * 24 * 5);
				response.addCookie(passwordCookie);
			} else {
				error = "入力データが間違っています。";
				cmd = "login";
				return;
			}

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、ログイン出来ません。";
			cmd = "login";
		} finally {

			if (error.equals("") && authority == 1) {
				// 既存ユーザー
				request.getRequestDispatcher("/topPage").forward(request, response);
			} else if (error.equals("") && authority == 2) {
				// 管理者
				request.getRequestDispatcher("/view/menu.jsp").forward(request, response);
			}
			// ログインエラーの場合
			else if (cmd.equals("login")) {
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/login.jsp").forward(request, response);
			} else {
				// エラーがある場合、error.jspにフォワード
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
